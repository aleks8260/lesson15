<?php

require_once "db.class.php";

$db = new Database('localhost', 'root', '', 'lesson15');

$users = $db->selectAll('SELECT * FROM users');
echo "<pre>";
    print_r($users);
echo "</pre>";

?>