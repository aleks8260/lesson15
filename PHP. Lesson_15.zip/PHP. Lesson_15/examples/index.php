<h1><a href="register.php">Регистрация</a></h1>
<br/>
<?=isset($_GET['msg']) ? $_GET['msg'] : '';?>